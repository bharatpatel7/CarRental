#include "q2.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv){

  //Pointer to the stack
  int i = 0;
  Operand * stack = NULL;
  


  //Loop through the second command line arguement, containing the operands and the numbers 
  for(i = 0; i < strlen(argv[1]); ++i){

    /*Remember data passed from command line is a char data type*/
    
    /* **Hint** You will need to perform stack operations that 
    we implemented here to achieve the expected output */
    
 
  }
  
  

  return 0;
}