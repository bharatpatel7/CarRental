# CIS2520-F24-A2

## Student Information 
Name : 

Student Number : 

## Assignment Overview
What is the assignment about?  
Explain the purpose of the program and what it accomplishes.

## Resources 
Did you use any resources (for example book, notes etc) in this assignment?

## Implementation
Is the assignment complete? If not, mention what part of the assignment is missing or incomplete.
